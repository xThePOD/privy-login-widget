=== Privy Login Widget ===
Contributors: yourusername
Tags: privy, login, authentication, wallet
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0.0
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Add Privy authentication to your WordPress site with a simple widget.

== Description ==

The Privy Login Widget allows you to easily add Privy authentication to your WordPress site. It provides a simple way to authenticate users using email or wallet login methods.

= Features =

* Simple installation and setup
* Customizable button text and appearance
* Supports email and wallet login methods
* Responsive design
* Dark/light theme support
* WordPress shortcode support
* Settings page for easy configuration

== Installation ==

1. Upload the `privy-login-widget-clean` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Settings > Privy Login and enter your Privy App ID
4. Use the shortcode `[privy_login]` in any post or page

== Frequently Asked Questions ==

= How do I get my Privy App ID? =

You can get your Privy App ID from your Privy dashboard at https://console.privy.io

= Can I customize the button text? =

Yes! You can customize the button text using the shortcode:
`[privy_login button_text="Custom Text"]`

= Can I change the theme? =

Yes! You can change the theme using the shortcode:
`[privy_login theme="light"]`

== Changelog ==

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
Initial release 